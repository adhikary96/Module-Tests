package com.cg.PCM.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PCM.bean.Product;
import com.cg.PCM.exception.ProductException;
import com.cg.PCM.repo.IProductRepo;

/**
 * Class name: ProductServiceImpl
 * Interface Implemented: IProductService
 * Purpose of the Class: To create a service class that transfers the data from the controller
 * 						 to the Repository layer, and also performs validations.
 * Number of methods: 6
 * Methods:	createProduct 	:Takes input as a JSon Product object, returns JSon product object 
 * 			updateProduct	:Takes input as a JSon Product object, returns JSon product object 
 * 								with updated details
 * 			deleteProduct	:Takes Product Id as input, returns the Product id to display as deleted
 * 			viewProducts	:Returns a list of JSon product objects to be displayed
 * 			findProduct		:Takes Product Id as input, returns the specific product object 
 * 			validateProduct	:Validates the details in the product
 * 
 * Author: Deepraj Adhikary
 * Date of creation: 8th August, 2018
 * Date of modification: 8th August, 2018
 *  
 */

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private IProductRepo repo;
	
	/**
	 * Name of method:createProduct
	 * parameters expected: Product object (JSon form)
	 * return type: product object
	 * purpose: To create an entry in the database
	 *  
	 * Exception: ProductException
	 */
	
	@Override
	public Product createProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		if (validateProduct(product))
			repo.save(product);
		return product;
	}
	
	/**
	 * Name of method:updateProduct
	 * parameters expected: Product object (JSon form)
	 * return type: product object
	 * purpose: To update an entry in the database
	 *  
	 * Exception: ProductException
	 */

	@Override
	public Product updateProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		if(viewProducts().contains(product))
			throw new ProductException("No Such product there to update");
		Product product2 = repo.getOne(product.getId());
		product2.setPrice(product.getPrice());
		return repo.save(product2);
	}
	
	/**
	 * Name of method:deleteProduct
	 * parameters expected: String id
	 * return type: product object
	 * purpose: To delete an entry in the database
	 *  
	 * Exception: ProductException
	 */

	@Override
	public String deleteProduct(String id) throws ProductException {
		// TODO Auto-generated method stub
		if(repo.getOne(id) == null)
			throw new ProductException("No product present to be deleted");
		repo.deleteById(id);
		return id;
	}
	
	/**
	 * Name of method:viewProduct
	 * parameters expected: none
	 * return type: product object
	 * purpose: To display all the entries present in the database
	 *  
	 * Exception: ProductException
	 */

	@Override
	public List<Product> viewProducts() throws ProductException {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
	/**
	 * Name of method:findProduct
	 * parameters expected: String id
	 * return type: product object
	 * purpose: To display specific entry present in the database
	 *  
	 * Exception: ProductException
	 */

	@Override
	public Product findProduct(String id) throws ProductException {
		// TODO Auto-generated method stub
		try {
			return repo.getOne(id);
		} catch(Exception e) {
			// TODO: handle exception
			throw new ProductException("No product present");
		}
		
	}
	
	/**
	 * Name of method:validateProduct
	 * parameters expected: product object
	 * return type: boolean
	 * purpose: To validate the entries in the product
	 *  
	 * Exception: ProductException
	 */
	
	private boolean validateProduct(Product product) throws ProductException {
		if(product == null)
			throw new ProductException("Product doesnot exist");
		if(product.getId().isEmpty())
			throw new ProductException("ID cannot be empty");
		if(product.getName().isEmpty())
			throw new ProductException("Name cannot be empty");
		if(!product.getName().matches("[A-Za-z]{2,}"))
			throw new ProductException("name must have only alphabets");
		if(product.getModel().isEmpty())
			throw new ProductException("Product name cannot be empty");
		if(product.getPrice()<0)
			throw new ProductException("Price must be more than zero");
		return true;
		
	}

}
