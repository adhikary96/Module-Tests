package com.cg.PCM.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Class name: Product
 * Purpose of the Class: To create a table using JPA annotations in MySQL Database
 * Methods: Getters and Setters for the private variables
 * Variables: 	Id		: to store product id
 * 			  	name	: to store product name
 * 			  	model	: to store model of the product
 * 			  	price	: to store products price
 * 
 * Author: Deepraj Adhikary
 * Date of creation: 8th August, 2018
 * Date of modification: 8th August, 2018
 *  
 */

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
public class Product {
	
	@Id private String id;
	private String name;
	private String model;
	private double price;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}
	
	
}
