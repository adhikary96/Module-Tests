package com.cg.PCM.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.PCM.bean.Product;

/**
 * Interface name: IProductRepo
 * Purpose of the Class: To create a repository interface
 * 
 * Author: Deepraj Adhikary
 * Date of creation: 8th August, 2018
 * Date of modification: 8th August, 2018
 *  
 */

@Repository
public interface IProductRepo extends JpaRepository<Product, String>{
		
}
