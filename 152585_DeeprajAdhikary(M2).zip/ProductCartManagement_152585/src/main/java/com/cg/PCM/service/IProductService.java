package com.cg.PCM.service;

import java.util.List;

import com.cg.PCM.bean.Product;
import com.cg.PCM.exception.ProductException;

/**
 * Interface name: IProductService
 * Purpose of the Class: To create a service interface that is used to create the abstract methods.
 * Number of methods: 6
 * Methods:	createProduct 	:Takes input as a JSon Product object, returns JSon product object 
 * 			updateProduct	:Takes input as a JSon Product object, returns JSon product object 
 * 								with updated details
 * 			deleteProduct	:Takes Product Id as input, returns the Product id to display as deleted
 * 			viewProducts	:Returns a list of JSon product objects to be displayed
 * 			findProduct		:Takes Product Id as input, returns the specific product object 
 * 			validateProduct	:Validates the details in the product
 * 
 * Author: Deepraj Adhikary
 * Date of creation: 8th August, 2018
 * Date of modification: 8th August, 2018
 *  
 */

public interface IProductService {
	
	Product createProduct(Product product) throws ProductException;
	Product updateProduct(Product product) throws ProductException;
	String deleteProduct(String id) throws ProductException;
	List<Product> viewProducts() throws ProductException;
	Product findProduct(String id) throws ProductException;
	
}
