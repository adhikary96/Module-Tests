package com.cg.PCM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EntityScan("com.cg.PCM.bean")
@ComponentScan("com.cg.PCM")
@EnableJpaRepositories("com.cg.PCM")
@SpringBootApplication
public class ProductCartManagement152585Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagement152585Application.class, args);
	}
}
