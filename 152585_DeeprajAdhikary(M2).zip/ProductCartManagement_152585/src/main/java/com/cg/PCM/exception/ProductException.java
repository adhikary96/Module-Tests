package com.cg.PCM.exception;

public class ProductException extends Exception {

	public ProductException() {

	}

	public ProductException(String message) {
		super(message);
	}

}
