package com.cg.PCM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.PCM.bean.Product;
import com.cg.PCM.exception.ProductException;
import com.cg.PCM.service.IProductService;

/**
 * Class name: ProductController
 * Purpose of the Class: To create a Front Controller that transfers the data from the Client (POSTMAN)
 * 						 to the service layer.
 * Number of methods: 5
 * Methods:	createProduct 	:Takes input as a JSon Product object, returns JSon product object 
 * 			updateProduct	:Takes input as a JSon Product object, returns JSon product object 
 * 								with updated details
 * 			deleteProduct	:Takes Product Id as input, returns the Product id to display as deleted
 * 			viewProducts	:Returns a list of JSon product objects to be displayed
 * 			findProduct		:Takes Product Id as input, returns the specific product object 
 * 
 * Author: Deepraj Adhikary
 * Date of creation: 8th August, 2018
 * Date of modification: 8th August, 2018
 *  
 */

@RestController
public class ProductController {
	
	@Autowired
	private IProductService service;
	
	/**
	 * Name of method:createProduct
	 * parameters expected: Product object (JSon form)
	 * return type: product object
	 * purpose: To create an entry in the database
	 *  
	 * Exception: ProductException
	 */
	
	
	@RequestMapping(value="/createProduct", method=RequestMethod.POST)
	public Product createProduct(@RequestBody Product product) throws ProductException {
		try {
			return service.createProduct(product);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
	}
	
	/**
	 * Name of method:updateProduct
	 * parameters expected: Product object (JSon form)
	 * return type: product object
	 * purpose: To update an entry in the database
	 *  
	 * Exception: ProductException
	 */
	
	@RequestMapping(value="/updateProduct", method=RequestMethod.PUT)
	public Product updateProduct(@RequestBody Product product) throws ProductException{
		try {
			return service.updateProduct(product);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
	}
	
	/**
	 * Name of method:deleteProduct
	 * parameters expected: String id
	 * return type: product object
	 * purpose: To delete an entry in the database
	 *  
	 * Exception: ProductException
	 */
	
	@RequestMapping(value="/deleteProduct", method=RequestMethod.DELETE)
	public String deleteProduct(String id) throws ProductException{
		try {
			return service.deleteProduct(id);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
	}
	
	/**
	 * Name of method:viewProduct
	 * parameters expected: none
	 * return type: product object
	 * purpose: To display all the entries present in the database
	 *  
	 * Exception: ProductException
	 */
	
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public List<Product> viewProducts() throws ProductException{
		try {
			return service.viewProducts();
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
	}
	
	/**
	 * Name of method:findProduct
	 * parameters expected: String id
	 * return type: product object
	 * purpose: To display specific entry present in the database
	 *  
	 * Exception: ProductException
	 */
	
	@RequestMapping(value="/findProduct", method=RequestMethod.GET)
	public Product findProduct(String id) throws ProductException{
		try {
			return service.findProduct(id);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			throw new ProductException(e.getMessage());
		}
	}
}
