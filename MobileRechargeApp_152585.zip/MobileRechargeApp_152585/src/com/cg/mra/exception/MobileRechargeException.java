package com.cg.mra.exception;

public class MobileRechargeException extends Exception {
	public MobileRechargeException(){
		super();
	}
	public MobileRechargeException(String message){
		super(message);
	}

}
